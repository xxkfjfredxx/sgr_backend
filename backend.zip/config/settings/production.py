from .base import *  # noqa: F403,F401

DEBUG = False

ALLOWED_HOSTS = ["mi_dominio.com"]
