from django.apps import AppConfig


class CambiosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.cambios"
