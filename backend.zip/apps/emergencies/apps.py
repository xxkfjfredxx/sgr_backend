from django.apps import AppConfig


class EmergenciesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.emergencies"
