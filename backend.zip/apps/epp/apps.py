from django.apps import AppConfig


class EppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.epp"
