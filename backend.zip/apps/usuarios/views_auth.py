# apps/usuarios/views_auth.py
from django.contrib.auth import authenticate, login, logout
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework.authtoken.models import Token
from django_tenants.utils import set_current_tenant
from .serializers import UserSerializer


class LoginView(APIView):
    permission_classes = [permissions.AllowAny]
    authentication_classes = []  # Ignora token entrante

    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")

        # Autenticación del usuario
        user = authenticate(request, email=email, password=password)
        
        if user is None:
            return Response(
                {"detail": "Credenciales inválidas"},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        # Reglas multitenant
        if user.is_superuser:
            # Si es un superusuario, no necesitamos verificar la empresa
            pass  # El superusuario puede loguearse sin restricciones
        else:
            # Verificar que el usuario tenga una empresa asignada
            if user.company is None:
                return Response({"detail": "Usuario sin empresa"}, status=status.HTTP_400_BAD_REQUEST)

            # Establecer el tenant (empresa) activo para la solicitud
            company = user.company  # `company` es la empresa (tenant) asociada al usuario
            tenant_id = company.tenant.id  # Este es el ID del tenant, no el de la empresa
            set_current_tenant(company)  # Establecer el tenant actual

        # Generar token de autenticación
        Token.objects.filter(user=user).delete()  # Eliminar token antiguo si existe
        token = Token.objects.create(user=user)  # Crear un nuevo token
        login(request, user)  # Iniciar sesión en Django

        # Responder con el token y detalles del usuario
        return Response(
            {
                "token": token.key,
                "user": UserSerializer(user).data,
                "tenant_id": tenant_id,  # El ID del tenant asociado a la empresa
                "company_name": company.name,  # Nombre de la empresa (tenant)
            },
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    """
    POST /logout/  – Borra token y cierra sesión. Idempotente.
    """

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        # 1️⃣ Elimina el token si existe
        Token.objects.filter(user=request.user).delete()

        # 2️⃣ Cierra la sesión de Django
        logout(request)

        # 3️⃣ Siempre responde 200 OK (idempotencia)
        return Response(
            {"message": "Sesión cerrada correctamente"},
            status=status.HTTP_200_OK,
        )


class MeView(APIView):
    """
    GET /me/  – Devuelve los datos del usuario autenticado.
    """

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)
