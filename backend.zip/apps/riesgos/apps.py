from django.apps import AppConfig


class RiesgosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.riesgos"
