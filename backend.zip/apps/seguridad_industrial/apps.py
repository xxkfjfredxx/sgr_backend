from django.apps import AppConfig


class SeguridadIndustrialConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.seguridad_industrial"
