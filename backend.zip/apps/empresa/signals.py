# apps/empresa/signals.py

from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.tenants.models import Tenant  # Asegúrate de importar correctamente el modelo Tenant
from .models import Company  # Asegúrate de importar el modelo Company

@receiver(post_save, sender=Company)
def create_tenant_for_company(sender, instance, created, **kwargs):
    """
    Crea un nuevo tenant automáticamente cuando se crea una nueva empresa.
    """
    if created:  # Solo se ejecuta si la empresa fue creada (no modificada)
        # Crear un nuevo tenant asociado con la empresa
        tenant = Tenant.objects.create(
            name=instance.name,  # Usamos el nombre de la empresa para el tenant
            db_label=instance.nit  # O cualquier identificador único que desees
        )
        # Asociar el tenant con la empresa recién creada
        instance.tenant = tenant
        instance.save()
