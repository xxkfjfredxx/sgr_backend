# apps/empresa/models.py
from django.db import models
from django_multitenant.models import TenantModel
from apps.utils.mixins import AuditMixin
from apps.tenants.models import Tenant
from django.db import connection

# apps/empresa/models.py
import logging

# Configura el logger
logger = logging.getLogger(__name__)

class Company(TenantModel):
    name = models.CharField(max_length=150)
    nit = models.CharField(max_length=30, unique=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    sector = models.CharField(max_length=100, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.pk:  # Si es una nueva empresa
            tenant = Tenant.objects.create(
                name=self.name,
                db_label=self.nit  # Usamos NIT o cualquier identificador único como db_label
            )
            self.tenant = tenant  # Asocia el tenant con la empresa
        super().save(*args, **kwargs)

    class Meta:
        db_table = "companies"
        ordering = ["name"]

    def __str__(self):
        return self.name