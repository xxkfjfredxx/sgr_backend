# Deja esto vacío o bórralo si no tienes otras vistas individuales aquí
urlpatterns = []
