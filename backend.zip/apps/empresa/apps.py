from django.apps import AppConfig


class EmpresaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.empresa"

    def ready(self):
        # Importar y registrar las señales cuando la app se carga
        import apps.empresa.signals