from django.apps import AppConfig


class PausasActivasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.pausas_activas"
